@extends('layouts.app')

@section('content')
<div class="container">
    {!! $blog->t01contenido !!}
</div>
@endsection
@section('js')

@endsection


