@extends('layouts.app')

@section('content')
<div class="container">
    <h3> para tener los beneficios de nuestro planes de fidelizacion</h3>
</div>
@endsection

@section('css')
@stop

@section('js')
@stop


