<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class T08detalleMonederoController extends Controller
{
    //
}
