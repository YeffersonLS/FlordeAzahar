<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Panel De Control</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido al panel de control de Flor de Azahar.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <?php if(env('APP_ENV') == "local"): ?>
        <link rel="stylesheet" href="css/admin_custom.css">
    <?php else: ?>
        <link rel="stylesheet" href="public/css/admin_custom.css">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/admin/index.blade.php ENDPATH**/ ?>