<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Categorias</h2>
    <div class="row">
        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="category">
                <a href="<?php echo e(route('category.show', ['id' => $category->t02id])); ?>">
                    <div class="card">
                        <img src="<?php echo e(asset($category->t02image_path)); ?>" class="card-img-top-category">
                        <h5 class="card-title-category"><?php echo e($category->t02nombre); ?></h5>
                    </div>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/category/home.blade.php ENDPATH**/ ?>