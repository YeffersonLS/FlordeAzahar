<?php $__env->startSection('css'); ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/pure/1.0.1/pure-min.css">
<style>
    label[for="quantity"] {
        font-size: 0.8rem; /* Reducir tamaño de fuente */
        margin-bottom: 0.5rem; /* Disminuir espaciado inferior */
        font-size: 13px;
    }

    input[type="number"] {
        border-radius: 5px; /* Redondear esquinas */
        border: none; /* Eliminar bordes */
        box-shadow: none; /* Eliminar sombras */
        width: 5rem; /* Ajustar ancho */
        padding: 0.5rem; /* Ajustar relleno */
        font-family: sans-serif; /* Fuente simple */
        font-size: 13px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <img src="<?php echo e(asset($image->image_path)); ?>" alt="<?php echo e($product->t02nombre); ?>" id="mainImage" class="img-fluid">
        </div>
        <div class="col-md-6">
            <h2><?php echo e($product->t02nombre); ?></h2>
            <p><?php echo $product->t04descripcion; ?></p>
            <p>Precio: $<?php echo e($product->t04precio); ?></p>
            <div class="mt-3">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset($img->image_path)); ?>" alt="<?php echo e($product->t02nombre); ?>" class="thumbnail" onclick="changeImage('<?php echo e($img->image_path); ?>')" style="max-width: 100px; max-height: 100px;">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-3">
                <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="form-control" id="t04id" name="t04id" value="<?php echo e($product->t04id); ?>" hidden >
                    <label for="quantity">Cantidad:</label>
                    <input type="number" name="quantity" id="quantity" min="1" value="1">
                    <button type="submit" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> Agregar al carrito</button>
                </form>


                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    function changeImage(imagePath) {
        document.getElementById('mainImage').src = "<?php echo e(asset('')); ?>" + imagePath;
    };

    // $(document).ready(function() {
    // $("#guardar").click(function() {
    //     const addToCartForm = document.querySelector('form[action="<?php echo e(route('cart.add')); ?>"]');

    //         addToCartForm.addEventListener('guardar', (event) => {
    //             event.preventDefault(); // Prevent default form submission

    //             const productId = document.getElementById('t04id').value;
    //             const quantity = document.getElementById('quantity').value;

    //             // Send the product ID and quantity to the controller using an AJAX request
    //             fetch('<?php echo e(route('cart.add')); ?>', {
    //                 method: 'POST',
    //                 headers: {
    //                     'Content-Type': 'application/json',
    //                     'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' // Add CSRF token for security
    //                 },
    //                 body: JSON.stringify({
    //                     product_id: productId,
    //                     quantity: quantity
    //                 })
    //             })
    //                 .then(response => response.json())
    //                 .then(data => {
    //                     // Handle the response from the controller (e.g., display a success message)
    //                     console.log('Producto añadido al carrito:', data);
    //                 })
    //                 .catch(error => {
    //                     console.error('Error al añadir al carrito:', error);
    //                 });
    //         });
    //     });
    // });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/products/product.blade.php ENDPATH**/ ?>