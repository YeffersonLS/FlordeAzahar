<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Catálogo de Productos</h2>
    <div class="row">
        <!-- Itera sobre tus productos y muestra cada uno de ellos -->
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="productos">
                <a href="<?php echo e(route('product.show', ['t04slug' => $product->t04slug])); ?>"><!-- Enlace al detalle del producto -->
                    <div class="card">
                        <img src="<?php echo e(asset($product->image_path)); ?>" class="card-img-top" alt="<?php echo e($product->t02nombre); ?>">
                        <div class="card-info">
                            <p class="subcategoria-productos"><?php echo e($product->t02nombre); ?></p>
                            <h5 class="card-title"><?php echo e($product->t04nombre); ?></h5>
                            <p class="card-money"><?php echo e('$' . $product->t04precio . ' MXN'); ?></p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/category/products.blade.php ENDPATH**/ ?>