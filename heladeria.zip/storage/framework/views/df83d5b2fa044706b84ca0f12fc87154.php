<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
        <h2>Tu Monedero</h2>
    </div>

    <!-- Mostrar el nombre completo de la persona -->
    <div>
        <h3>Nombre: <?php echo e(Auth::user()->sys01fullname); ?></h3>
    </div>

    <!-- Mostrar el valor del monedero -->
    <div class="monedero">
        <h3>Saldo en el monedero: <?php echo e($total.' MXN'); ?></h3>
    </div>
    <!-- Tabla de cargos en el monedero -->
    <h4>Cargos en el monedero:</h4>
    <table class="table">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Descripción</th>
                <th>Monto</th>
            </tr>
        </thead>
        <tbody>
            <?php if(isset($cargos)): ?>
            <?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cargo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cargo->fecha); ?></td>
                <td><?php echo e($cargo->descripcion); ?></td>
                <td><?php echo e($cargo->monto); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/pocketbook/home.blade.php ENDPATH**/ ?>