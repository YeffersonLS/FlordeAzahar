<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e('Flor de Azahar'); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- CSS -->
    <?php if(env('APP_ENV') == "local"): ?>
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('public/css/app.css')); ?>" rel="stylesheet">
    <?php endif; ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        #news-list li:not(:first-child) {
            display: none;
        }
    </style>
    <?php echo $__env->yieldContent('css'); ?>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>

    <?php if(session('mensaje')): ?>
        <div class="alert alert-success alert-dismissable">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>

    <div class="header-top header-top-ptb-1 d-none d-lg-block">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-6 col-lg-6">
                    <div class="header-info">
                        <ul>
                            <li><i class="fas fa-phone"></i> <a href="https://wa.link/2sgb9s">229 667 4807</a></li>
                            <li><i class="fas fa-map-marker-alt"></i><a href="https://maps.app.goo.gl/W8efXpjTtPCsK75U9" target="_blank" rel="noopener noreferrer"> C. 5 de Mayo 805-Local B, Centro, 95100 Tierra Blanca, Ver.</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="text-center">
                        <div id="news-flash" class="d-inline-block">
                            <ul id="news-list">
                                <li>Los mejores Helados <a href="/productos">Ver mas</a></li>
                                <li>La mejor Calidad</li>
                                <li>Se parte de la Familia <a href="#">Unete</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="app">
        <nav class="navbar navbar-expand-md navbar-pink shadow-sm"> <!-- Cambiar la clase a navbar-pink -->
            <div class="container">
                <?php if(env('APP_ENV') == "local"): ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img class="rounded-circle" src="<?php echo e(asset('vendor/adminlte/dist/img/AdminLTELogo.svg')); ?>" alt="Logo" style="width: 40px; height: 40px;">
                    <?php echo e('Flor de Azahar'); ?>

                </a>
            <?php else: ?>
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img class="rounded-circle" src="<?php echo e(asset('public/vendor/adminlte/dist/img/AdminLTELogo.svg')); ?>" alt="Logo" style="width: 60px; height: 60px;">
                <?php echo e('Flor de Azahar'); ?>

            </a>
            <?php endif; ?>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    

                    <!-- Right Side Of Navbar -->
                    <div class="d-flex justify-content-center align-items-center mx-auto">
                        <form class="d-flex" action="<?php echo e(route('buscar')); ?>" method="GET">
                            <input class="form-control me-2" type="search" name="query" placeholder="Buscar" aria-label="Search">
                            <button class="btn btn-outline-light" type="submit">Buscar</button>
                        </form>
                    </div>

                    
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <i class="fas fa-user"></i> <!-- Icono de usuario -->
                                    <?php echo e(Auth::user()->sys01name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>

                                    <?php if(Auth::user()->sys01admin == true): ?>
                                        <a class="dropdown-item" href="/admin">Panel de control</a>
                                    <?php endif; ?>

                                    
                                        <a class="dropdown-item" href="/combosAgendados">Combos Agendados</a>
                                    
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <div>
                        <a href="/monedero" style="text-decoration: none; color: inherit;">
                            <span style="font-size: 1.2em;">💰</span> Monedero |
                        </a>
                    </div>

                    <div>
                        <a href="/carrito" style="text-decoration: none; color: inherit;">
                            <span style="font-size: 1.2em;">🛒</span>Carrito
                        </a>
                    </div>

                </div>
            </div>
        </nav>
    </div>

    <nav class="menu">
        <ul>
            <li><a href="/categorias">Ver Categorías</a></li>
            <li><a href="/productos">Productos</a></li>
            <li><a href="/combos">Combos</a></li>
            <li><a href="/blogs">BLOG</a></li>
            <li><a href="/tiendas">Tiendas</a></li>
            <li><a href="/contacto">Contacto</a></li>
            <li><a href="/nosotros">Nosotros</a></li>
        </ul>
    </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>

<footer class="footer">
    <div class="header-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>Contacto</h3>
                    <ul>
                        <li><i class="fas fa-phone"></i> Teléfono: 229 667 4807</li>
                        <li><i class="fas fa-envelope"></i> Correo electrónico: flor@example.com</li>
                        <li><i class="fas fa-map-marker-alt"></i> Dirección: C. 5 de Mayo 805-Local B, Centro, 95100 Tierra Blanca, Ver.</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h3>Síguenos</h3>
                    <ul class="list-inline">
                        <li><a href="https://www.facebook.com/profile.php?id=100093570651456"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a href="https://www.tiktok.com/@heladeriaflordeaz"><i class="fab fa-tiktok"></i> Tik Tok</a></li>
                        <li><a href="https://www.instagram.com/flordeazahargerencia/"><i class="fab fa-instagram"></i> Instagram</a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom-footer text-center">
        <div class="container">
            <p>&copy; 2024 Flor de Azahar. Todos los derechos reservados.</p>
        </div>
    </div>
</footer>

<script src="<?php echo e(asset('public/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendor/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendor/adminlte/dist/js/adminlte.min.js')); ?>"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Selecciona la lista de noticias
        var newsList = document.getElementById('news-list');

        // Obtiene todos los elementos <li> de la lista
        var newsItems = newsList.getElementsByTagName('li');

        // Inicializa el índice actual del elemento de la lista
        var currentIndex = 0;

        // Función para cambiar el elemento de la lista cada 10 segundos
        setInterval(function() {
            // Oculta el elemento actual
            newsItems[currentIndex].style.display = 'none';

            // Incrementa el índice o reinicia si se llega al final
            currentIndex = (currentIndex + 1) % newsItems.length;

            // Muestra el nuevo elemento
            newsItems[currentIndex].style.display = 'block';
        }, 5000); // 5 segundos
    });
</script>
<?php echo $__env->yieldContent('js'); ?>

</html>
<?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/layouts/app.blade.php ENDPATH**/ ?>