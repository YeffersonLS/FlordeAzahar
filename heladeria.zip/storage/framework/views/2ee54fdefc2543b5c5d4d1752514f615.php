<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Combos Agendados</h1>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Combo</th>
                <th>Hora de entrega</th>
                <th>Pago</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($q->t10nombre); ?></td>
                <td><?php echo e($q->t11hora); ?></td>
                <td><?php echo e($q->t11pago ? 'Sí' : 'No'); ?></td>
                <td>Acciones</td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tr>
            <tr>
                </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/combos.blade.php ENDPATH**/ ?>