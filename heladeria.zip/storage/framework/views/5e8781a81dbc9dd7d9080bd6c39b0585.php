<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>