<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Carrito de compras</h1>

    <?php if($check): ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Total</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->t04nombre); ?></td>
                    <td><?php echo e($item->t04precio); ?></td>
                    <td><?php echo e($item->t12cantidad); ?></td>
                    <td><?php echo e($item->t04precio * $item->t12cantidad); ?></td>
                    <td>
                        <form action="<?php echo e(route('cart.delete')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" class="form-control" id="t12producto" name="t12producto" value="<?php echo e($item->t12producto); ?>" hidden >
                            <input type="text" class="form-control" id="t12carrito" name="t12carrito" value="<?php echo e($item->t12carrito); ?>" hidden >
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trahs"></i> Eliminar</button>
                        </form>
                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                
                
                <tr>
                    <td colspan="3">Total</td>
                    <td><?php echo e($total); ?></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
        <form action="<?php echo e(route('pay.cart')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" class="form-control" id="t12carrito" name="t12carrito" value="<?php echo e($item->t12carrito); ?>" hidden >
            <button type="submit" class="btn btn-success btn-lg">Proceder al pago</button>
        </form>
        <a href="#" class=""></a>
    <?php else: ?>
        <p class="text-center">Tu carrito está vacío.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/carrito.blade.php ENDPATH**/ ?>