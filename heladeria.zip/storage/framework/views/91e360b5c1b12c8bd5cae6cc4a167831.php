<?php $__env->startSection('title'); ?><?php echo $titulo; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
<?php echo $titulo; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php if(session('mensaje')): ?>
    <div class="alert alert-success alert-dismissable">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>

<div class="modal" id="modalConfirmar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Confirmación</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
                ¿Estás seguro de eliminar el soporte?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">No</button>
                <button type="button" onclick="eliminarSoporteConfirmado();" class="btn btn-danger">Sí</button>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card border-primary">
            <div class="card-header bg-primary">
                <h4 class="m-b-0 m-t-0 text-white">Datos Básicos</h4>
            </div>
            <div class="card-body">
                <?php if(isset($editMode)): ?>
                <form action="<?php echo e(route('admin.banners.update', ['banner' => $registro->t06id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                <form action="<?php echo e(route('admin.banners.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>

                    <div class="row form-group">
                        <div class="col-md-4">
                            <label for="t06descripcionimagen">Nombre o corta descripcion de la imagen</label>
                            <input type="text" id="t06descripcionimagen" name="t06descripcionimagen" class="form-control" value="<?php echo e($registro->t06descripcionimagen); ?>" >
                        </div>

                        <div class="col-md-4">
                            <label for="t06publicado">Activar visaulizacion Banner</label><br>
                            <input id="borrador" name="t06publicado" type="radio" value="0" <?php echo e($registro->t06publicado === 0 ? 'checked' : ''); ?>> Borrador<br>
                            <input id="publicado" name="t06publicado" type="radio" value="1" <?php echo e($registro->t06publicado === 1 ? 'checked' : ''); ?>> Publicado
                        </div>

                        <div class="col-md-4">
                            <label for="t06orden">Orden del banner</label>
                            <input id="t06orden" name="t06orden" type="number" class="form-control" value="<?php echo e($registro->t06orden); ?>"
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="card-body">
                            <div class="col-md-12">
                                <label for="images">Agrega Imagenes al Producto</label><br>
                                <input id="images" type="file" name="images[]" accept="image/*" multiple>
                            </div>
                        </div>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="row form-group">
                        <div class="col-md-12 text-center">
                            <a href="<?php echo url('admin/banners'); ?>" class="btn btn-warning"><i class="fa fa-reply"></i> Cancelar</a>
                            <button type="submit" id="guardar" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
                            <input type="submit" id="btnSubmit" style="display: none;">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<input type="hidden" name="folder" id="folder">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    $("#guardar").click(function(){
        $("#btnSubmit").click();
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/admin/banners/create.blade.php ENDPATH**/ ?>