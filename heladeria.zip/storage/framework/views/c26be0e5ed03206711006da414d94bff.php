<?php $__env->startSection('title'); ?><?php echo $titulo; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
<?php echo $titulo; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php if(session('mensaje')): ?>
    <div class="alert alert-success alert-dismissable">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>

<div class="row">
    <div class="col-12">
        <div class="card border-primary">
            <div id='calendar'></div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
<link href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css' rel='stylesheet'>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>
<script src="<?php echo e(asset('public/vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#t03nombre").stringToSlug({
            setEvents: 'keyup keydown blur',
            getPut: '#t03slug',
            space: '-'
        });

        $("#guardar").click(function(){
            $("#btnSubmit").click();
        });
    });



    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            locale: 'es',
            themeSystem: 'bootstrap5',
            timeZone: 'UTC',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                // right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
                right: 'dayGridMonth'

            },
            // weekNumbers: true,
            // dayMaxEvents: true,
            events: <?php echo json_encode($events, 15, 512) ?>
        });
        calendar.render();
      });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/admin/combos/calendary.blade.php ENDPATH**/ ?>