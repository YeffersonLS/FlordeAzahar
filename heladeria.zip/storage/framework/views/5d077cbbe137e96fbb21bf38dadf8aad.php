<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>