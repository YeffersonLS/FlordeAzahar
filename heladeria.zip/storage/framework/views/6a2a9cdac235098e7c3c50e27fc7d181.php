<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Aceptar Términos y Condiciones')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('monedero.crear')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="terminos" name="terminos">
                                <label class="form-check-label" for="terminos">
                                    <?php echo 'Acepto los Términos y Condiciones de Heladeria Flor de Azahar para la creacion de mi monedero virtual.<br>1°El valor de mi monedero no sera redimible a pesos<br>2°El monedero sera unico e intransferible'; ?>

                                </label>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn-continuar" disabled>
                            <?php echo e(__('Continuar')); ?>

                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    // Habilitar o deshabilitar el botón de continuar según si se ha marcado el checkbox
    document.getElementById('terminos').addEventListener('change', function() {
        document.getElementById('btn-continuar').disabled = !this.checked;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/pocketbook/create.blade.php ENDPATH**/ ?>