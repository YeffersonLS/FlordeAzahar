<?php echo e($slot); ?>

<?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>