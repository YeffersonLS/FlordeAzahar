<?php $__env->startSection('title'); ?><?php echo $titulo; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
<?php echo $titulo; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php if(session('mensaje')): ?>
    <div class="alert alert-success alert-dismissable">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>

<div class="row">
    <div class="col-12">
        <div class="card border-primary">
            <div class="card-header bg-primary">
                <h4 class="m-b-0 m-t-0 text-white">Datos Básicos</h4>
            </div>
            <div class="card-body">
                <?php if(isset($editMode)): ?>
                <form action="<?php echo e(route('admin.tags.update', ['tag' => $registro->t03id])); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                <form action="<?php echo e(route('admin.tags.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>



                    <div class="row form-group">
                        <div class="col-md-12">
                            <label for="t03slug">Slug SEO</label>
                            <input id="t03slug" name="t03slug" class="form-control" value="<?php echo e($registro->t03slug); ?>" required></input>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-6">
                            <label for="t03nombre">Nombre/Título</label>
                            <input type="text" id="t03nombre" name="t03nombre" class="form-control" value="<?php echo e($registro->t03nombre); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="t03tipo">Tipo</label>
                            <select id="t03tipo" name="t03tipo" class="form-control" required>
                                <option value="" <?php echo e($registro->t03tipo == '' ? 'selected' : ''); ?>>Selecciona una opción</option>
                                <option value="BLOGS" <?php echo e($registro->t03tipo == 'BLOGS' ? 'selected' : ''); ?>>BLOGS</option>
                                <option value="PRODUCTOS" <?php echo e($registro->t03tipo == 'PRODUCTOS' ? 'selected' : ''); ?>>PRODUCTOS</option>
                                <!-- Agrega más opciones según sea necesario -->
                            </select>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col">
                            <label for="t03color">Color de la Etiqueta</label>
                            <input id="t03color" name="t03color" value="<?php echo e($registro->t03color); ?>" type="color">
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12 text-center">
                            <a href="<?php echo url('admin/tags'); ?>" class="btn btn-warning"><i class="fa fa-reply"></i> Cancelar</a>
                            <button type="submit" id="guardar" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
                            <input type="submit" id="btnSubmit" style="display: none;">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('public/vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#t03nombre").stringToSlug({
        setEvents: 'keyup keydown blur',
        getPut: '#t03slug',
        space: '-'
    });

        $("#guardar").click(function(){
            $("#btnSubmit").click();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/admin/tags/create.blade.php ENDPATH**/ ?>