<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Combos</h2>
    <div class="row">
        <?php $__currentLoopData = $combos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-10">
            <div class="combo">
                <a href="<?php echo e(route('combos.show', ['id' => $combo->t10id])); ?>">
                    <div class="blog-image-container">
                        <img src="<?php echo e(asset($combo->t10image)); ?>" class="card-img-top-blog">
                    </div>
                    <div class="card-blog">
                        <h5 class="card-title-blog"><?php echo e($combo->t10nombre); ?></h5>
                        
                        
                    </div>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/combos/home.blade.php ENDPATH**/ ?>