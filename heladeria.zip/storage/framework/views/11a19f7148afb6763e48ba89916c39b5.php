<?php $__env->startSection('title'); ?><?php echo $titulo; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
<?php echo $titulo; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php if(session('mensaje')): ?>
    <div class="alert alert-success alert-dismissable">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>

<div class="row">
    <div class="col-12">
        <div class="card border-primary">
            <div class="col-10">
                <form action="<?php echo e(route('admin.diary.update', ['diary' => $registro->t11id])); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>

                    <div class="col-md-4">
                        <label>Estado de Pago</label><br>
                        <input id="Activo" name="t11pago" type="radio" value="0" <?php echo e($registro->t11pago === 0 ? 'checked' : ''); ?>> No pago<br>
                        <input id="Inactivo" name="t11pago" type="radio" value="1" <?php echo e($registro->t11pago === 1 ? 'checked' : ''); ?>> Pago
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control" id="t11combo" name="t11combo" value="<?php echo e($registro->t11id); ?>" hidden >
                    </div>
                    <div class="mb-3">
                        <label for="t11nombre" class="form-label">Nombre de la persona a Entregar</label>
                        <input type="text" class="form-control" id="t11nombre" name="t11nombre" placeholder="Ingresa tu nombre" value="<?php echo e($registro->t11nombre); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="t11numero" class="form-label">Telefono de la persona a Entregar</label>
                        <input type="number" class="form-control" id="t11numero" name="t11numero" placeholder="Ingresa el Telefono" value="<?php echo e($registro->t11numero); ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label for="t11hora">Hora de entrega</label>
                        <select id="t11hora" name="t11hora" class="form-control">
                            <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($hora); ?>"><?php echo e($hora); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="t11direccion" class="form-label">Direccion</label>
                        <textarea class="form-control" id="t11direccion" name="t11direccion" rows="3" placeholder="Escribe la direccion de entrega" required> <?php echo e($registro->t11direccion); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Enviar</button>

                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('public/vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js')); ?>"></script>
<script type="text/javascript">


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/admin/combos/edit.blade.php ENDPATH**/ ?>