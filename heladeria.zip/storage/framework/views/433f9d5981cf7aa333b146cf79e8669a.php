<?php $__env->startSection('css'); ?>
<style>
    .mt-3 {
        margin-top: 15px;
    }

    .button {
        display: inline-block;
        padding: 10px 20px;
        background-color: pink;
        color: black;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s;
        cursor: pointer;
        border: 2px black solid;

    }

    .button:hover {
        background-color: white;
        color: black;

    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <img src="<?php echo e(asset($image->image_path)); ?>" alt="<?php echo e($combo->t10nombre); ?>" id="mainImage" class="img-fluid">
        </div>
        <div class="col-md-6">
            <h2><?php echo e($combo->t10nombre); ?></h2>
            <p><?php echo $combo->t10descripcion; ?></p>
            <p>Precio: $<?php echo e($combo->t10valor); ?></p>
             
            <div class="mt-3">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset($img->image_path)); ?>" alt="<?php echo e($combo->t02nombre); ?>" class="thumbnail" onclick="changeImage('<?php echo e($img->image_path); ?>')" style="max-width: 100px; max-height: 100px;">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-4">
                <a id="agendar" href="<?php echo e(auth()->check() ? route('agendar', ['id' => $combo->t10id]) : route('register')); ?>" class="button">Agenda tu combo</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function changeImage(imagePath) {
        document.getElementById('mainImage').src = "<?php echo e(asset('')); ?>" + imagePath;
    }

    $(document).ready(function() {
        $("#agendar").click(function(event) {
            console.log($(this).attr("href"));
            if ($(this).attr("href") === 'https://heladeriaflordeazahar.com/register') {
                alert("Necesita estar registrado o logeado para poder Agendar tu combo");
            }
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145310150/domains/heladeriaflordeazahar.com/public_html/heladeria/resources/views/combos/combo.blade.php ENDPATH**/ ?>